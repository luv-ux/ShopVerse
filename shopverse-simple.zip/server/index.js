const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 5000;
const DB_PATH = path.join(__dirname, 'data', 'db.json');

app.use(cors());
app.use(express.json());

function readDB() {
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
}
function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// ---------- AUTH ----------
app.post('/api/auth/register', (req, res) => {
  const db = readDB();
  const { name, email, password, role, store_name } = req.body;

  if (db.users.find(u => u.email === email)) {
    return res.status(409).json({ error: 'Email already registered' });
  }

  const newUser = {
    id: db.users.length ? Math.max(...db.users.map(u => u.id)) + 1 : 1,
    name, email, password,
    role: role === 'seller' ? 'seller' : 'buyer'
  };
  db.users.push(newUser);

  if (newUser.role === 'seller') {
    const newStore = {
      id: db.stores.length ? Math.max(...db.stores.map(s => s.id)) + 1 : 1,
      sellerId: newUser.id,
      name: store_name || `${name}'s Store`
    };
    db.stores.push(newStore);
  }

  writeDB(db);
  res.status(201).json({ message: 'Registered successfully', user: newUser });
});

app.post('/api/auth/login', (req, res) => {
  const db = readDB();
  const { email, password } = req.body;
  const user = db.users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const { password: _pw, ...safeUser } = user;
  res.json({ user: safeUser, token: `fake-jwt-${user.id}` });
});

// ---------- PRODUCTS ----------
app.get('/api/products', (req, res) => {
  const db = readDB();
  let products = db.products;
  const { q, category } = req.query;
  if (q) products = products.filter(p => p.title.toLowerCase().includes(q.toLowerCase()));
  if (category) products = products.filter(p => p.categoryId === Number(category));
  res.json({ products });
});

app.get('/api/products/:id', (req, res) => {
  const db = readDB();
  const product = db.products.find(p => p.id === Number(req.params.id));
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json({ product });
});

app.post('/api/products', (req, res) => {
  const db = readDB();
  const { title, description, price, stock, categoryId, storeId } = req.body;
  const store = db.stores.find(s => s.id === Number(storeId)) || db.stores[0];
  const newProduct = {
    id: db.products.length ? Math.max(...db.products.map(p => p.id)) + 1 : 1,
    storeId: store.id,
    storeName: store.name,
    title, description,
    price: Number(price),
    stock: Number(stock),
    categoryId: Number(categoryId) || 1
  };
  db.products.push(newProduct);
  writeDB(db);
  res.status(201).json({ message: 'Product created', product: newProduct });
});

app.delete('/api/products/:id', (req, res) => {
  const db = readDB();
  db.products = db.products.filter(p => p.id !== Number(req.params.id));
  writeDB(db);
  res.json({ message: 'Product deleted' });
});

// ---------- ORDERS ----------
app.post('/api/orders', (req, res) => {
  const db = readDB();
  const { buyerId, items, address } = req.body;
  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const newOrder = {
    id: db.orders.length ? Math.max(...db.orders.map(o => o.id)) + 1 : 1,
    buyerId, items, address, total,
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  db.orders.push(newOrder);

  items.forEach(item => {
    const product = db.products.find(p => p.id === item.productId);
    if (product) product.stock = Math.max(0, product.stock - item.quantity);
  });

  writeDB(db);
  res.status(201).json({ message: 'Order placed', order: newOrder });
});

app.get('/api/orders', (req, res) => {
  const db = readDB();
  const buyerId = Number(req.query.buyerId);
  const orders = db.orders.filter(o => o.buyerId === buyerId);
  res.json({ orders });
});

// ---------- CATEGORIES ----------
app.get('/api/categories', (req, res) => {
  const db = readDB();
  res.json({ categories: db.categories });
});

app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.listen(PORT, () => console.log(`ShopVerse server running on http://localhost:${PORT}`));
