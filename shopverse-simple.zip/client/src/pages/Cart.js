import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Cart() {
  const [cart, setCart] = useState(JSON.parse(localStorage.getItem('sv_cart') || '[]'));
  const navigate = useNavigate();

  const remove = (id) => {
    const updated = cart.filter(i => i.id !== id);
    setCart(updated);
    localStorage.setItem('sv_cart', JSON.stringify(updated));
  };

  const total = cart.reduce((sum, i) => sum + i.price * i.quantity, 0);

  return (
    <div className="container py-4" style={{ maxWidth: 700 }}>
      <h2 className="mb-4">Your Cart</h2>
      {cart.length === 0
        ? <div className="text-center py-5"><p className="text-muted">Cart is empty</p><Link to="/products" className="btn btn-primary">Shop Now</Link></div>
        : <>
          {cart.map(item => (
            <div key={item.id} className="card mb-3 p-3 d-flex flex-row align-items-center gap-3">
              <div className="flex-grow-1">
                <h6 className="mb-1">{item.title}</h6>
                <small className="text-muted">Qty: {item.quantity}</small>
              </div>
              <strong>Rs.{(item.price * item.quantity).toLocaleString()}</strong>
              <button className="btn btn-sm btn-outline-danger" onClick={() => remove(item.id)}>Remove</button>
            </div>
          ))}
          <div className="card p-3 d-flex flex-row justify-content-between align-items-center">
            <h5 className="mb-0">Total: <strong className="text-primary">Rs.{total.toLocaleString()}</strong></h5>
            <button className="btn btn-primary" onClick={() => navigate('/checkout')}>Checkout</button>
          </div>
        </>
      }
    </div>
  );
}
