import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
const API = 'http://localhost:5000/api';

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => { axios.get(`${API}/products/${id}`).then(r => setProduct(r.data.product)); }, [id]);

  const addToCart = () => {
    const cart = JSON.parse(localStorage.getItem('sv_cart') || '[]');
    const existing = cart.find(i => i.id === product.id);
    if (existing) existing.quantity++;
    else cart.push({ ...product, quantity: 1, productId: product.id });
    localStorage.setItem('sv_cart', JSON.stringify(cart));
    alert('Added to cart!');
  };

  if (!product) return <div className="container py-5 text-center"><div className="spinner-border text-primary"></div></div>;

  return (
    <div className="container py-4" style={{ maxWidth: 700 }}>
      <div className="card p-4">
        <h2 className="mb-1">{product.title}</h2>
        <p className="text-muted mb-2">Sold by: {product.storeName}</p>
        <h3 className="text-primary mb-3">Rs.{Number(product.price).toLocaleString()}</h3>
        <p className="mb-3">{product.description}</p>
        <div className="d-flex gap-2">
          <button className="btn btn-primary" onClick={addToCart}>Add to Cart</button>
          <span className="btn btn-outline-secondary disabled">Stock: {product.stock}</span>
        </div>
      </div>
    </div>
  );
}
